<?php

/* overall/layout.twig */
class __TwigTemplate_7e4fa70851718f6d1b4947cf20494a29f1dc951e8f745cbe357d83ec2e1062dd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'appHead' => array($this, 'block_appHead'),
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"es\">
  <head>
    ";
        // line 5
        echo "    ";
        echo $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->base_assets();
        echo "
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
    
     ";
        // line 10
        echo " 
    <link href=\"https://fonts.googleapis.com/css?family=Quicksand:400,700%7CCabin:400%7CDancing+Script\" rel=\"stylesheet\">
    ";
        // line 13
        echo "    ";
        // line 15
        echo "
    ";
        // line 17
        echo "    ";
        // line 19
        echo "
    ";
        // line 20
        echo " 
    ";
        // line 22
        echo "
    ";
        // line 23
        echo " 
    ";
        // line 25
        echo "    <link rel=\"stylesheet\" href=\"views/app/css/csslimpio.css\">
    ";
        // line 27
        echo "    <link href=\"views/app/images/logocampanu.ico\" rel=\"shortcut icon\" type=\"image/x-icon\" />

    ";
        // line 30
        echo "    <title>";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "site", array()), "name", array()), "html", null, true);
        echo "</title>

    ";
        // line 33
        echo "    ";
        $this->displayBlock('appHead', $context, $blocks);
        // line 36
        echo "    
    <!--[if lt IE 9]>
      <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
      <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->
  </head>
  <body>

    ";
        // line 45
        echo "    ";
        $this->displayBlock('appBody', $context, $blocks);
        // line 48
        echo "
    ";
        // line 50
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "framework", array()), "debug", array())) {
            // line 51
            echo "      ";
            // line 52
            echo "      <script src=\"views/app/js/jdev.min.js\"></script>
    ";
        } else {
            // line 54
            echo "      ";
            // line 55
            echo "      <script src=\"views/app/js/jquery.min.js\"></script>
    ";
        }
        // line 57
        echo "
    ";
        // line 59
        echo "    <script src=\"views/app/js/bootstrap.min.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/owl.carousel.min.js\"></script>
    <script src=\"https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false\"></script>
    <script type=\"text/javascript\" src=\"js/google-map.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/main.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/expand.js\"></script>
    ";
        // line 66
        echo "    ";
        $this->displayBlock('appFooter', $context, $blocks);
        // line 69
        echo "  </body>
</html>
";
    }

    // line 33
    public function block_appHead($context, array $blocks = array())
    {
        // line 34
        echo "      <!-- :) -->
    ";
    }

    // line 45
    public function block_appBody($context, array $blocks = array())
    {
        // line 46
        echo "      <!-- :) -->
    ";
    }

    // line 66
    public function block_appFooter($context, array $blocks = array())
    {
        // line 67
        echo "      <!-- :) -->
    ";
    }

    public function getTemplateName()
    {
        return "overall/layout.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 67,  142 => 66,  137 => 46,  134 => 45,  129 => 34,  126 => 33,  120 => 69,  117 => 66,  109 => 59,  106 => 57,  102 => 55,  100 => 54,  96 => 52,  94 => 51,  91 => 50,  88 => 48,  85 => 45,  75 => 36,  72 => 33,  66 => 30,  62 => 27,  59 => 25,  56 => 23,  53 => 22,  50 => 20,  47 => 19,  45 => 17,  42 => 15,  40 => 13,  36 => 10,  27 => 5,  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"es\">
  <head>
    {# Formato #}
    {{ base_assets()|raw }}
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
    
     {# Google font #} 
    <link href=\"https://fonts.googleapis.com/css?family=Quicksand:400,700%7CCabin:400%7CDancing+Script\" rel=\"stylesheet\">
    {# Estilos #}
    {# <link href=\"views/app/vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\" />
    <link href=\"views/app/css/framework.min.css\" rel=\"stylesheet\" /> #}

    {# owl carrousel #}
    {# <link type=\"text/css\" rel=\"stylesheet\" href=\"views/app/css/owl.carousel.css\" />
    <link type=\"text/css\" rel=\"stylesheet\" href=\"views/app/css/owl.theme.default.css\" /> #}

    {# Font Awesome Icon #} 
    {# <link rel=\"stylesheet\" href=\"views/app/css/font-awesome.min.css\"> #}

    {# Custom stlylesheet #} 
    {# <link type=\"text/css\" rel=\"stylesheet\" href=\"views/app/css/style.css\"/> #}
    <link rel=\"stylesheet\" href=\"views/app/css/csslimpio.css\">
    {# favicon #}
    <link href=\"views/app/images/logocampanu.ico\" rel=\"shortcut icon\" type=\"image/x-icon\" />

    {# Título #}
    <title>{{ config.site.name }}</title>

    {# Extras en el head #}
    {% block appHead %}
      <!-- :) -->
    {% endblock %}
    
    <!--[if lt IE 9]>
      <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
      <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->
  </head>
  <body>

    {# Contenido real #}
    {% block appBody %}
      <!-- :) -->
    {% endblock %}

    {# Carga de jQuery #}
    {% if config.framework.debug %}
      {# jQuery para ver errores de ajax vía consola, no eliminar #}
      <script src=\"views/app/js/jdev.min.js\"></script>
    {% else %}
      {# jQuery para su plantilla, este puede ser modificado a voluntad #}
      <script src=\"views/app/js/jquery.min.js\"></script>
    {% endif %}

    {# Scripts globales #}
    <script src=\"views/app/js/bootstrap.min.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/owl.carousel.min.js\"></script>
    <script src=\"https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false\"></script>
    <script type=\"text/javascript\" src=\"js/google-map.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/main.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/expand.js\"></script>
    {# Footer #}
    {% block appFooter %}
      <!-- :) -->
    {% endblock %}
  </body>
</html>
", "overall/layout.twig", "C:\\xampp\\htdocs\\Restaurante\\app\\templates\\overall\\layout.twig");
    }
}
