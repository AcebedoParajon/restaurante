<?php

/* administrar/editar.twig */
class __TwigTemplate_b6727dbec4059a02fad7990c046c3dd018e5fcd9a970335db9506b072542f57f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "administrar/editar.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "    <div class=\"container\">
    \t<h4 class=\"tex-center\">Editar plato</h4>
        <form role=\"form\" id=\"administrar_form\">
        \t<div class=\"form-group\">
\t\t\t\t<input type=\"hidden\" name=\"id_platos\" value=\"";
        // line 7
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "id_platos", array()), "html", null, true);
        echo "\" />
\t\t\t\t<label for=\"\">Categoria</label>
\t\t\t\t<select name=\"categoria\">
\t\t\t\t\t<option value=\"entrantes\"";
        // line 10
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "categoria", array()) == "entrantes")) {
            echo "selected";
        }
        echo ">entrante</option>
\t\t\t\t\t<option value=\"carnes\"";
        // line 11
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "categoria", array()) == "carnes")) {
            echo "selected";
        }
        echo ">carnes</option>
\t\t\t\t\t<option value=\"mariscos\"";
        // line 12
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "categoria", array()) == "mariscos")) {
            echo "selected";
        }
        echo ">mariscos</option>
\t\t\t\t\t<option value=\"pescados\"";
        // line 13
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "categoria", array()) == "pescados")) {
            echo "selected";
        }
        echo ">pescados</option>
\t\t\t\t\t<option value=\"parrillada mariscos pescados\"";
        // line 14
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "categoria", array()) == "parrillada mariscos pescados")) {
            echo "selected";
        }
        echo ">parrillada mariscos pescados</option>
\t\t\t\t\t<option value=\"cuchara\"";
        // line 15
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "categoria", array()) == "cuchara")) {
            echo "selected";
        }
        echo ">cuchara</option>
\t\t\t\t</select><br>
\t\t\t\t<label for=\"\">Plato</label>
\t\t\t\t<input type=\"text\" class=\"form-control\" value=\"";
        // line 18
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "plato", array()), "html", null, true);
        echo "\" name=\"plato\">
\t\t\t\t<label for=\"\">precio</label>
\t\t\t\t<input type=\"text\" class=\"form-control\" value=\"";
        // line 20
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "precio", array()), "html", null, true);
        echo "\" name=\"precio\">
\t\t\t\t<label for=\"\">descripcion</label>
\t\t\t\t<input type=\"text\" class=\"form-control\" value=\"";
        // line 22
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "descripcion", array()), "html", null, true);
        echo "\" name=\"descripcion\">
\t\t\t</div>
            <div class=\"form-group\">
                <button type=\"button\" class=\"btn btn-primary\" id=\"administrar\">Enviar</button>
            </div>
        </form>
    </div>
";
    }

    // line 30
    public function block_appFooter($context, array $blocks = array())
    {
        // line 31
        echo "\t<script src=\"views/app/plugins/js/jquery-confirm.min.js\"></script>
    <script src=\"views/app/js/administrar/editar.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "administrar/editar.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 31,  104 => 30,  92 => 22,  87 => 20,  82 => 18,  74 => 15,  68 => 14,  62 => 13,  56 => 12,  50 => 11,  44 => 10,  38 => 7,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout' %}
{% block appBody %}
    <div class=\"container\">
    \t<h4 class=\"tex-center\">Editar plato</h4>
        <form role=\"form\" id=\"administrar_form\">
        \t<div class=\"form-group\">
\t\t\t\t<input type=\"hidden\" name=\"id_platos\" value=\"{{ data.id_platos }}\" />
\t\t\t\t<label for=\"\">Categoria</label>
\t\t\t\t<select name=\"categoria\">
\t\t\t\t\t<option value=\"entrantes\"{% if data.categoria == 'entrantes' %}selected{% endif %}>entrante</option>
\t\t\t\t\t<option value=\"carnes\"{% if data.categoria == 'carnes' %}selected{% endif %}>carnes</option>
\t\t\t\t\t<option value=\"mariscos\"{% if data.categoria == 'mariscos' %}selected{% endif %}>mariscos</option>
\t\t\t\t\t<option value=\"pescados\"{% if data.categoria == 'pescados' %}selected{% endif %}>pescados</option>
\t\t\t\t\t<option value=\"parrillada mariscos pescados\"{% if data.categoria == 'parrillada mariscos pescados' %}selected{% endif %}>parrillada mariscos pescados</option>
\t\t\t\t\t<option value=\"cuchara\"{% if data.categoria == 'cuchara' %}selected{% endif %}>cuchara</option>
\t\t\t\t</select><br>
\t\t\t\t<label for=\"\">Plato</label>
\t\t\t\t<input type=\"text\" class=\"form-control\" value=\"{{ data.plato }}\" name=\"plato\">
\t\t\t\t<label for=\"\">precio</label>
\t\t\t\t<input type=\"text\" class=\"form-control\" value=\"{{ data.precio }}\" name=\"precio\">
\t\t\t\t<label for=\"\">descripcion</label>
\t\t\t\t<input type=\"text\" class=\"form-control\" value=\"{{ data.descripcion }}\" name=\"descripcion\">
\t\t\t</div>
            <div class=\"form-group\">
                <button type=\"button\" class=\"btn btn-primary\" id=\"administrar\">Enviar</button>
            </div>
        </form>
    </div>
{% endblock %}
{% block appFooter %}
\t<script src=\"views/app/plugins/js/jquery-confirm.min.js\"></script>
    <script src=\"views/app/js/administrar/editar.js\"></script>
{% endblock %}", "administrar/editar.twig", "/storage/ssd4/489/5421489/public_html/app/templates/administrar/editar.twig");
    }
}
