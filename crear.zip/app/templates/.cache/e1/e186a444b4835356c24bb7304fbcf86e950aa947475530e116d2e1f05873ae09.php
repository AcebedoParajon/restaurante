<?php

/* administrar/editar.twig */
class __TwigTemplate_37dbd170451bf70e1e9ca697c2adc5eb871b2ed9ee9d81db4b935bad41d69b0b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "administrar/editar.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "    <div class=\"container\">
    \t<h4 class=\"tex-center\">Editar plato</h4>
        <form role=\"form\" id=\"administrar_form\">
        \t<div class=\"form-group\">
\t\t\t\t<input type=\"hidden\" name=\"id_platos\" value=\"";
        // line 7
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "id_platos", array()), "html", null, true);
        echo "\" />
\t\t\t\t<label for=\"\">Categoria</label>
\t\t\t\t<select name=\"categoria\">
\t\t\t\t\t<option value=\"entrantes\"";
        // line 10
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "categoria", array()) == "entrantes")) {
            echo "selected";
        }
        echo ">entrante</option>
\t\t\t\t\t<option value=\"carnes\"";
        // line 11
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "categoria", array()) == "carnes")) {
            echo "selected";
        }
        echo ">carnes</option>
\t\t\t\t\t<option value=\"mariscos\"";
        // line 12
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "categoria", array()) == "mariscos")) {
            echo "selected";
        }
        echo ">mariscos</option>
\t\t\t\t\t<option value=\"pescados\"";
        // line 13
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "categoria", array()) == "pescados")) {
            echo "selected";
        }
        echo ">pescados</option>
\t\t\t\t\t<option value=\"parrillada mariscos pescados\"";
        // line 14
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "categoria", array()) == "parrillada mariscos pescados")) {
            echo "selected";
        }
        echo ">parrillada mariscos pescados</option>
\t\t\t\t\t<option value=\"cuchara\"";
        // line 15
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "categoria", array()) == "cuchara")) {
            echo "selected";
        }
        echo ">cuchara</option>
\t\t\t\t\t<option value=\"menucasa\"";
        // line 16
        if ((twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "categoria", array()) == "menucasa")) {
            echo "selected";
        }
        echo ">menucasa</option>
\t\t\t\t</select><br>
\t\t\t\t<label for=\"\">Plato</label>
\t\t\t\t<input type=\"text\" class=\"form-control\" value=\"";
        // line 19
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "plato", array()), "html", null, true);
        echo "\" name=\"plato\">
\t\t\t\t<label for=\"\">precio</label>
\t\t\t\t<input type=\"text\" class=\"form-control\" value=\"";
        // line 21
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "precio", array()), "html", null, true);
        echo "\" name=\"precio\">
\t\t\t\t<label for=\"\">descripcion</label>
\t\t\t\t<textarea rows=\"10\" class=\"form-control\" name=\"descripcion\"  onkeypress=\"event.cancelBubble=true;\">";
        // line 23
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "descripcion", array()), "html", null, true);
        echo "</textarea>
\t\t\t</div>
            <div class=\"form-group\">
                <button type=\"button\" class=\"btn btn-success\" id=\"administrar\">Enviar</button>
                <a href=\"administrar/\" class=\"btn btn-primary\">Atrás</a>
            </div>
        </form>
    </div>
";
    }

    // line 32
    public function block_appFooter($context, array $blocks = array())
    {
        // line 33
        echo "\t<script src=\"views/app/plugins/js/jquery-confirm.min.js\"></script>
    <script src=\"views/app/js/administrar/editar.js\"></script>

 
";
    }

    public function getTemplateName()
    {
        return "administrar/editar.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 33,  111 => 32,  98 => 23,  93 => 21,  88 => 19,  80 => 16,  74 => 15,  68 => 14,  62 => 13,  56 => 12,  50 => 11,  44 => 10,  38 => 7,  32 => 3,  29 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "administrar/editar.twig", "C:\\xampp\\htdocs\\campanu\\app\\templates\\administrar\\editar.twig");
    }
}
