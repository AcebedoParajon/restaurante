<?php

/* login/login.twig */
class __TwigTemplate_f3132aadbc6c0ee531f72aa11783e4968507cd2ce2495975ce5ce92ee70d5639 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "login/login.twig", 1);
        $this->blocks = array(
            'appHead' => array($this, 'block_appHead'),
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appHead($context, array $blocks = array())
    {
        // line 3
        echo "  <link rel=\"stylesheet\" href=\"views/app/plugins/css/jquery-confirm.min.css\" />
";
    }

    // line 5
    public function block_appBody($context, array $blocks = array())
    {
        // line 6
        echo "   <div class=\"row\">
    <div class=\"col-lg-12\">
      <form role=\"form\" enctype=\"application/x-www-form-urlencoded\" id=\"login_form\">
        <fieldset>
          <legend><h2 style=\"color:black;\">Página restringida, ingrese usuario y contraseña</h2></legend>
          <div class=\"alert hide\" id=\"ajax_login\"></div>

          <div class=\"form-group\">
            <label class=\"col-lg-6 control-label\" for=\"inputEmail\" style=\"color:black; text-align: left;\">Email</label>
            <div class=\"col-lg-8\">
              <input type=\"email\" name=\"email\" class=\"form-control\" placeholder=\"Su email\" required=\"\" autofocus=\"\" />
            </div>
          </div>

          <div class=\"form-group\">
            <label class=\"col-lg-6 control-label\" for=\"inputPassword\" style=\"color:black; text-align: left;\">Contraseña</label>
            <div class=\"col-lg-8\">
              <input type=\"password\" name=\"pass\" class=\"form-control\" placeholder=\"Su contraseña\" required=\"\" />
            </div>
          </div>
          <div class=\"form-group\">
            <div class=\"col-lg-6\">
              <button type=\"button\" id=\"login\" class=\"btn btn-sm btn-success\">Iniciar Sesión</button>
            </div>
          </div>
        </fieldset>
      </form>
    </div>
  </div>
";
    }

    // line 36
    public function block_appFooter($context, array $blocks = array())
    {
        // line 37
        echo "  <script src=\"views/app/plugins/js/jquery-confirm.min.js\"></script>
  <script src=\"views/app/js/login/login.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "login/login.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  77 => 37,  74 => 36,  41 => 6,  38 => 5,  33 => 3,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout' %}
{% block appHead %}
  <link rel=\"stylesheet\" href=\"views/app/plugins/css/jquery-confirm.min.css\" />
{% endblock %}
{% block appBody %}
   <div class=\"row\">
    <div class=\"col-lg-12\">
      <form role=\"form\" enctype=\"application/x-www-form-urlencoded\" id=\"login_form\">
        <fieldset>
          <legend><h2 style=\"color:black;\">Página restringida, ingrese usuario y contraseña</h2></legend>
          <div class=\"alert hide\" id=\"ajax_login\"></div>

          <div class=\"form-group\">
            <label class=\"col-lg-6 control-label\" for=\"inputEmail\" style=\"color:black; text-align: left;\">Email</label>
            <div class=\"col-lg-8\">
              <input type=\"email\" name=\"email\" class=\"form-control\" placeholder=\"Su email\" required=\"\" autofocus=\"\" />
            </div>
          </div>

          <div class=\"form-group\">
            <label class=\"col-lg-6 control-label\" for=\"inputPassword\" style=\"color:black; text-align: left;\">Contraseña</label>
            <div class=\"col-lg-8\">
              <input type=\"password\" name=\"pass\" class=\"form-control\" placeholder=\"Su contraseña\" required=\"\" />
            </div>
          </div>
          <div class=\"form-group\">
            <div class=\"col-lg-6\">
              <button type=\"button\" id=\"login\" class=\"btn btn-sm btn-success\">Iniciar Sesión</button>
            </div>
          </div>
        </fieldset>
      </form>
    </div>
  </div>
{% endblock %}
{% block appFooter %}
  <script src=\"views/app/plugins/js/jquery-confirm.min.js\"></script>
  <script src=\"views/app/js/login/login.js\"></script>
{% endblock %}", "login/login.twig", "C:\\xampp\\htdocs\\campanu\\app\\templates\\login\\login.twig");
    }
}
