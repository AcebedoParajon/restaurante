<?php

/* home/home.twig */
class __TwigTemplate_d69d36ebfc810ec97a29e80e139feab5e4ecbf3108a3c5c16dad689c262c96b3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "home/home.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "   <!-- Header -->
        <header id=\"header\">

            <!-- Top nav -->
            <div id=\"top-nav\">
                <div class=\"container\">

                    <!-- logo -->
                    <div class=\"logo\">
                        <a href=\"#\">Aquí el logo</a>
                    </div>
                    <!-- logo -->
                    <div class=\"xs-hidden\">
                        <div class=\"home-content\">
                            <h1 class=\"hidden-xs cabecera text-center\">Restaurante Sidrería marisquería</h1>
                        </div>
                    </div>

                    <!-- Mobile toggle -->
                    <button class=\"navbar-toggle\">
                        <span></span>
                    </button>
                    <!-- Mobile toggle -->

                    <!-- social links -->
                    <ul class=\"social-nav hidden-xs\">
                        <li><a href=\"https://www.facebook.com/elcampanu\"><i class=\"fa fa-facebook\"></i></a></li>
                        <li><a href=\"https://twitter.com/elcampanu\"><i class=\"fa fa-twitter\"></i></a></li>
                    </ul>
                <!-- /social links -->

                </div>
            </div>
            <!-- /Top nav -->

            <!-- Bottom nav -->
            <div id=\"bottom-nav\">
                <div class=\"container\">
                <nav id=\"nav\">

                    <!-- nav -->
                    <ul class=\"main-nav nav navbar-nav\">
                        <li><a href=\"index.php\">Inicio</a></li>
                        <li><a href=\"#about\">Un poco de historia</a></li>
                        <li><a href=\"#menu\">Nuestros platos</a></li>
                        ";
        // line 49
        echo "                        <!-- <li><a href=\"index.html#gallery\">Gallery</a></li> -->
                        <li><a href=\"#restaurantes\">Restaurantes</a></li>
                        <li><a href=\"#reservation\">Contacto y reservas</a></li>
                    </ul>
                    <!-- /nav -->

                    <!-- button nav -->
                    <ul class=\"cta-nav\">
                        <li><a href=\"#reservation\" class=\"main-button\">Reserve</a></li>
                    </ul>
                    <!-- button nav -->

                    <!-- contact nav -->
                    <ul class=\"contact-nav nav navbar-nav\">
                        ";
        // line 64
        echo "                        <li ><i class=\"fa fa-map-marker\"></i> 
                            Ribadesella,
                            Cangas de Onís, 
                            Oviedo
                        </li>
                    </ul>
                    <!-- contact nav -->

                </nav>
                </div>
            </div>
            <!-- /Bottom nav -->


        </header>
        <!-- /Header -->

        <!-- Home -->
        <div id=\"home\" class=\"banner-area\">

            <!-- Backgound Image -->
            <div class=\"bg-image bg-parallax overlay\" style=\"background-image:url(views/app/images/fondo1.jpg)\"></div>
            <!-- /Backgound Image -->

            <div class=\"home-wrapper\">

                <div class=\"col-md-10 col-md-offset-1 text-center\">
                    <div class=\"home-content\">
                        <h2 class=\"animated slideInLeft\">Sidrería Restaurante</h2>
                        <h4 class=\"animated slideInRight white-text lead\">Restaurante marisquería. Carnes a la parrilla</h4>
                        <a href=\"#menu\"><button class=\"animated slideInUp main-button\">Nuestros platos</button></a>
                    </div>
                </div>

            </div>

        </div>
        <!-- /Home -->

        <!-- About -->
        <div id=\"about\" class=\"section\">

            <!-- container -->
            <div class=\"container\">

                <!-- row -->
                <div class=\"row\">

                    <!-- section header -->
                    <div class=\"section-header text-center\">
                        <h4 class=\"sub-title\">Sobre nosotros</h4>
                        <h2 class=\"title animado\">Restaurantes Restaurante</h2>
                    </div>
                    <!-- /section header -->

                    <!-- about content -->
                    <div class=\"col-md-5\">
                        <h4 class=\"lead\">Bienvenidos a Restaurante. Desde 1998, ofreciendo platos tradicionales de la máxima calidad.</h4>
                    </div>
                    <!-- /about content -->

                    <!-- about content -->
                    <div class=\"col-md-7\">
                        <p>En José Manuel Mori Cuesta 'El Marqués', propietario de los restaurantes Restaurante de Oviedo, Cangas de Onís y Ribadesella, se aúnan dos pasiones; la pesca deportiva y la gastronomía. Criado a orillas del Sella, junto al Puente Romano, en una familia de gran tradición pesquera, aprendió desde pequeñín de los mejores y más míticos pescadores asturianos.<br>

                        José Manuel fundó Restaurante de La Venta, Cangas de Onís, en 1998, establecimiento que se traslada en 2002 a Ribadesella. En 2009 vuelve a abrir sus puertas en Cangas, esta vez junto al Puente Romano. En 2013 se inaugura Restaurante de Oviedo, en el centro mismo del casco antiguo de la capital asturiana. Organizador de multitud de jornadas gastronómicas por toda España, Mori es uno de los grandes divulgadores de la gastronomía asturiana fuera de las fronteras del Principado y sus restaurantes han sido distinguidos con el sello de la Cofradía de Pescadores “Virgen de Guía” de Ribadesella, garantía de pescado fresco y de calidad.<br>

                        Probablemente el número uno de los pescadores de salmón asturianos, José Manuel ha capturado hasta en cinco ocasiones Restaurante, el primer salmón de la temporada que se pesca en los ríos asturianos, y en dos ocasiones más en la vecina Cantabria. Ganchero de lujo para importantes personalidades nacionales e internacionales de visita deportiva por los ríos asturianos, es además un gran coleccionista de utensilios de pesca antiguos, que expone en sus tres restaurantes.</p>
                        <br>
                        <h4>Campanu <small>(el salmón)</small></h4>
                        <p>Se conoce como campanu al primer salmón que se pesca en los ríos asturianos y cántabros al comienzo de la campaña. En general, se usa esa denominación para el primer salmón de cada uno de los ríos, pero el que recibe el mayor protagonismo es el primero que se pesca en la temporada, sea del río que sea. La excepcionalidad dRestaurante hace que su subasta pública alcance precios de venta muy elevados.<br>

                        Se le conoce con este peculiar nombre dado que hace años (dicen que desde la Edad Media), cuando se pescaba el primer salmón todas las iglesias hacían repicar sus campanas para dar a conocer el hecho.</p>
                    </div>
                    <!-- /about content -->

                    <!-- Gallery Slider -->
                    <div class=\"col-md-12\">
                        <div id=\"Gallery\" class=\"owl-carousel owl-theme\">

                            <!-- single column -->
                            <div class=\"Gallery-item\">

                                <!-- single image -->
                                <div class=\"Gallery-img\" style=\"background-image:url(views/app/images/twitter6.jpg)\"></div>
                                <!-- /single image -->

                            </div>
                            <!-- single column -->

                            <!-- single column -->
                            <div class=\"Gallery-item\">

                                <!-- single image -->
                                <div class=\"Gallery-img\" style=\"background-image:url(views/app/images/twitter2.jpg)\"></div>
                                <!-- /single image -->

                                <!-- single image -->
                                <div class=\"Gallery-img\" style=\"background-image:url(views/app/images/twitter3.jpg)\"></div>
                                <!-- /single image -->

                            </div>
                            <!-- single column -->

                            <!-- single column -->
                            <div class=\"Gallery-item\">

                                <div class=\"item-column\">
                                    <!-- single image -->
                                    <div class=\"Gallery-img\" style=\"background-image:url(views/app/images/twitter4.jpg)\"></div>
                                    <!-- /single image -->

                                    <!-- single image -->
                                    <div class=\"Gallery-img\" style=\"background-image:url(views/app/images/twitter5.jpg)\"></div>
                                    <!-- /single image -->
                                </div>

                                <div class=\"item-column\">
                                    <!-- single image -->
                                    <div class=\"Gallery-img\" style=\"background-image:url(views/app/images/facebook1.jpg)\"></div>
                                    <!-- /single image -->

                                    <!-- single image -->
                                    <div class=\"Gallery-img\" style=\"background-image:url(views/app/images/facebook2.jpg)\"></div>
                                    <!-- /single image -->
                                </div>

                            </div>
                            <!-- /single column -->

                        </div>
                    </div>
                    <!-- /Gallery Slider -->


                </div>
                <!-- /row -->

            </div>
            <!-- /container -->

        </div>
        <!-- /About -->


        <!-- Menu -->
        <div id=\"menu\" class=\"section\">

            <!-- Backgound Image -->
            <div class=\"bg-image bg-parallax overlay\" style=\"background-image:url(views/app/images/fondopescados.jpg)\"></div>
            <!-- /Backgound Image -->

            <!-- container -->
            <div class=\"container\">

                <!-- row -->
                <div class=\"row\">

                    <div class=\"section-header text-center\">
                        <h4 class=\"sub-title\">Descubre</h4>
                        <h2 class=\"title white-text\">Nuestros platos</h2>
                    </div>

                    <!-- menu nav -->
                    <ul class=\"menu-nav\">
                      <li class=\"active\"><a data-toggle=\"tab\" href=\"#menu1\">Entrantes</a></li>
                      <li><a data-toggle=\"tab\" href=\"#menu2\">Pescados y mariscos</a></li>
                      <li><a data-toggle=\"tab\" href=\"#menu3\">Carnes</a></li>
                      <li><a data-toggle=\"tab\" href=\"#menu4\">De cuchara</a></li>
                      <li><a data-toggle=\"tab\" href=\"#menu5\">Menú de la casa</a></li>
                    </ul>
                    <!-- /menu nav -->

                    <!-- menu content -->
                    <div id=\"menu-content\" class=\"tab-content\">
                            
                        <!-- menu1 -->
                        <div id=\"menu1\" class=\"tab-pane fade in  active\">
                            ";
        // line 242
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_array_batch(($context["datos"] ?? null), 2));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 243
            echo "                            <div class=\"row\">
                                ";
            // line 244
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["row"]);
            foreach ($context['_seq'] as $context["_key"] => $context["d"]) {
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "categoria", array()) == "entrantes")) {
                    // line 245
                    echo "                                <div class=\"col-md-6\">
                                    <div class=\"single-dish\">
                                        <div class=\"single-dish-heading\">
                                            <h4 class=\"name\">";
                    // line 248
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "plato", array()), "html", null, true);
                    echo "</h4>
                                            <h4 class=\"price\">";
                    // line 249
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "precio", array()), "html", null, true);
                    echo "€</h4>
                                        </div>
                                        <p>";
                    // line 251
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "descripcion", array()), "html", null, true);
                    echo ".</p>
                                    </div>
                                </div>
                                ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['d'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 254
            echo "                        
                            </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 257
        echo "
                            ";
        // line 259
        echo "                            <div id=\"vermas\" class=\"row hidden text-center\">
                                <div class=\"col-md-12\">
                                    <input type=\"button\" value=\"Ver más\" onclick=\"vermas()\" class=\"main-button\">
                                </div>
                            </div>

                            ";
        // line 266
        echo "                            <div id=\"vermenos\" class=\"row hidden text-center\">
                                <div class=\"col-md-12\">
                                    <input type=\"button\" value=\"Ver menos\" onclick=\"vermenos()\" class=\"main-button\">
                                </div>
                            </div>
                        </div>
                        <!-- /menu1 -->

                         <!-- menu2 -->
                        <div id=\"menu2\" class=\"tab-pane fade in\">
                            <div class=\"col-md-12 text-center\">
                                <h3>Mariscos</h3>
                            </div>
                            ";
        // line 279
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_array_batch(($context["datos"] ?? null), 2));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 280
            echo "                            <div class=\"row\">
                                ";
            // line 281
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["row"]);
            foreach ($context['_seq'] as $context["_key"] => $context["d"]) {
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "categoria", array()) == "mariscos")) {
                    // line 282
                    echo "                                <div class=\"col-md-6\">
                                    <div class=\"single-dish\">
                                        <div class=\"single-dish-heading\">
                                            <h4 class=\"name\">";
                    // line 285
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "plato", array()), "html", null, true);
                    echo "</h4>
                                            <h4 class=\"price\">";
                    // line 286
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "precio", array()), "html", null, true);
                    echo "€</h4>
                                        </div>
                                        <p>";
                    // line 288
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "descripcion", array()), "html", null, true);
                    echo "</p>
                                    </div>
                                </div>
                                ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['d'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 292
            echo "                            </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 294
        echo "                            <!-- FIN MARISCOS -->

                            <div class=\"col-md-12 text-center\">
                                <h3>Parrilladas de pescados y mariscos</h3>
                            </div>
                            ";
        // line 299
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_array_batch(($context["datos"] ?? null), 2));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 300
            echo "                            <div class=\"row\">
                                ";
            // line 301
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["row"]);
            foreach ($context['_seq'] as $context["_key"] => $context["d"]) {
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "categoria", array()) == "parrillada mariscos pescados")) {
                    // line 302
                    echo "                                <div class=\"col-md-6\">
                                    <div class=\"single-dish\">
                                        <div class=\"single-dish-heading\">
                                            <h4 class=\"name\">";
                    // line 305
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "plato", array()), "html", null, true);
                    echo "</h4>
                                            <h4 class=\"price\">";
                    // line 306
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "precio", array()), "html", null, true);
                    echo "€</h4>
                                        </div>
                                        <p>";
                    // line 308
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "descripcion", array()), "html", null, true);
                    echo "</p>
                                    </div>
                                </div>
                                ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['d'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 312
            echo "                            </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 314
        echo "                            <!-- FIN PARRILLADAS -->

                            <div class=\"col-md-12 text-center\">
                                <h3>Pescados<small> Precios según lonja</small></small></h3>
                            </div>
                            ";
        // line 319
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_array_batch(($context["datos"] ?? null), 2));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 320
            echo "                            <div class=\"row\">
                                ";
            // line 321
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["row"]);
            foreach ($context['_seq'] as $context["_key"] => $context["d"]) {
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "categoria", array()) == "pescados")) {
                    // line 322
                    echo "                                <div class=\"col-md-6\">
                                    <div class=\"single-dish\">
                                        <div class=\"single-dish-heading\">
                                            <h4 class=\"name\">";
                    // line 325
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "plato", array()), "html", null, true);
                    echo "</h4>
                                            <h4 class=\"price\">";
                    // line 326
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "precio", array()), "html", null, true);
                    echo "€</h4>
                                        </div>
                                        <p>";
                    // line 328
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "descripcion", array()), "html", null, true);
                    echo "</p>
                                    </div>
                                </div>
                                ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['d'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 332
            echo "                            </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 334
        echo "                            <!-- FIN PESCADOS -->

                        </div> 
                        <!-- FIN menu2 --> 

                        <!-- Menu 3 Carnes -->
                        <div id=\"menu3\" class=\"tab-pane fade in\">
                            <div class=\"col-md-12 text-center\">
                                <h3>Carnes</h3>
                            </div>
                            ";
        // line 344
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_array_batch(($context["datos"] ?? null), 2));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 345
            echo "                            <div class=\"row\">
                                ";
            // line 346
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["row"]);
            foreach ($context['_seq'] as $context["_key"] => $context["d"]) {
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "categoria", array()) == "carnes")) {
                    // line 347
                    echo "                                <div class=\"col-md-6\">
                                    <div class=\"single-dish\">
                                        <div class=\"single-dish-heading\">
                                            <h4 class=\"name\">";
                    // line 350
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "plato", array()), "html", null, true);
                    echo "</h4>
                                            <h4 class=\"price\">";
                    // line 351
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "precio", array()), "html", null, true);
                    echo "€</h4>
                                        </div>
                                        <p>";
                    // line 353
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "descripcion", array()), "html", null, true);
                    echo "</p>
                                    </div>
                                </div>
                                ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['d'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 357
            echo "                            </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 359
        echo "
                        </div>
                        <!-- FIN Menu 3 -->

                        <!-- Menu 4 cuchara -->
                        <div id=\"menu4\" class=\"tab-pane fade in\">
                            <div class=\"col-md-12 text-center\">
                                <h3>De Cuchara</h3>
                            </div>
                            ";
        // line 368
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_array_batch(($context["datos"] ?? null), 2));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 369
            echo "                            <div class=\"row\">
                                ";
            // line 370
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["row"]);
            foreach ($context['_seq'] as $context["_key"] => $context["d"]) {
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "categoria", array()) == "cuchara")) {
                    // line 371
                    echo "                                <div class=\"col-md-6\">
                                    <div class=\"single-dish\">
                                        <div class=\"single-dish-heading\">
                                            <h4 class=\"name\">";
                    // line 374
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "plato", array()), "html", null, true);
                    echo "</h4>
                                            <h4 class=\"price\">";
                    // line 375
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "precio", array()), "html", null, true);
                    echo "€</h4>
                                        </div>
                                        <p>";
                    // line 377
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "descripcion", array()), "html", null, true);
                    echo "</p>
                                    </div>
                                </div>
                                ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['d'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 381
            echo "                            </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 383
        echo "
                        </div>
                        <!-- FIN Menu 4 cuchara -->

                        <!-- Menu 5 menú de la casa -->
                        <div id=\"menu5\" class=\"tab-pane fade in\">
                            <div class=\"col-md-12 text-center\">
                                <h3>Menú de la casa</h3>
                            </div>
                            ";
        // line 392
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_array_batch(($context["datos"] ?? null), 2));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 393
            echo "                            <div class=\"row\">
                                ";
            // line 394
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["row"]);
            foreach ($context['_seq'] as $context["_key"] => $context["d"]) {
                if ((twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "categoria", array()) == "menucasa")) {
                    // line 395
                    echo "                                <div class=\"col-md-6\">
                                    <div class=\"single-dish\">
                                        <div class=\"single-dish-heading\">
                                            <h4 class=\"name\">";
                    // line 398
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "plato", array()), "html", null, true);
                    echo "</h4>
                                            <h4 class=\"price\">";
                    // line 399
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "precio", array()), "html", null, true);
                    echo "€</h4>
                                        </div>
                                        <p>";
                    // line 401
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "descripcion", array()), "html", null, true);
                    echo "</p>
                                    </div>
                                </div>
                                ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['d'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 405
            echo "                            </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 407
        echo "
                        </div>
                        <!-- FIN Menu 5 menú de la casa -->

                    </div>
                    <!-- /menu content -->

                </div>
                <!-- /row -->

            </div>
            <!-- /container -->

        </div>
        <!-- /Menu -->

        ";
        // line 537
        echo "
        <!-- Events -->
        <div id=\"restaurantes\" class=\"section\">

            <!-- container -->
            <div class=\"container\">

                <!-- row -->
                <div class=\"row\">

                    <!-- section header -->
                    <div class=\"section-header text-center\">
                        <h4 class=\"sub-title\">Visítanos en</h4>
                        <h2 class=\"title\">Nuestros restaurantes</h2>
                    </div>
                    <!-- /section header -->

                    <!-- single event -->
                    <div class=\"col-md-6\">
                        <div class=\"event\">
                            ";
        // line 563
        echo "                            <div class=\"event-content\">
                                <p><a href=\"tel:+34985860358\"><i class=\"fa fa-phone\"></i>985 86 03 58</a></p>
                                <h3><a href=\"#\">En Ribadesella</a></h3>
                                <p>Nuestro restaurante está emplazado en un lugar envidiable, en la Calle Marqueses de Argüelles nº9, con vistas al puerto de Ribadesella, nos aseguramos que los pescados y mariscos del Cantábrico lleguen a nuestras cocinas con la máxima calidad y frescura.<br>

                                Ribadesella, territorio colonizado desde tiempos prehistóricos, fue fundada por Alfonso X el Sabio. Fue uno de los principales puertos asturianos del siglo XIX.<br>
​
                                En la actualidad el concejo destaca por la variedad turística que ofrece a los visitantes sobretodo en lo que a naturaleza se refiere.</p>
                                <a href=\"#ribadesella\" class=\"main-button\" data-toggle=\"modal\">Ver mapa</a>
                            </div>
                        </div>
                    </div>
                    <!-- /single event -->

                    <!-- single event -->
                    <div class=\"col-md-6\">
                        <div class=\"event\">
                            ";
        // line 586
        echo "                            <div class=\"event-content\">
                                <p><a href=\"tel:+34985947446\"><i class=\"fa fa-phone\"></i> 985 94 74 46</a></p>
                                <h3><a href=\"#\">En Cangas de Onís.</a></h3>
                                <p>Se encuentra situado al pie del puente romano, en la calle peatonal que da acceso a subir caminando hacia el puente de Cangas de Onis, en un entorno incomparable podrás disfrutar de toda la calidad de nuestros pescados y mariscos.<br>

                                La población de Cangas de Onís está asentada en el entronque de los ríos Sella y Güeña.<br> 

                                La ciudad de Cangas de Onís fue capital del Reino de Asturias hasta el año 774. En este término municipal tuvo lugar en el año 722 la Batalla de Covadonga, donde Don Pelayo venció a las fuerzas musulmanas y consolidó un poder y prestigio que le permitió permanecer independiente y fundar el primer reino cristiano.</p>
                                <a href=\"#cangas\" class=\"main-button\" data-toggle=\"modal\">Ver mapa</a>
                            </div>
                        </div>
                    </div>
                    <!-- /single event -->

                    <!-- single event -->
                    <div class=\"col-md-6\">
                        <div class=\"event\">
                            ";
        // line 609
        echo "                            <div class=\"event-content\">
                                <p><a href=\"tel:+34985215193\"><i class=\"fa fa-phone\"></i>985 21 51 93</a></p>
                                <h3><a href=\"#\">En Oviedo.</a></h3>
                                <p>En el centro de Oviedo, en la Calle Jesús nº1, está nuestro restaurante más nuevo. En un local de varias plantas, donde podrás disfrutar de nuestra terraza.<br>

                                Oviedo (Uviéu o Uvieo en asturiano) es una ciudad de origen medieval (siglo VIII) y es capital del Principado de Asturias. Además es el centro comercial, religioso, administrativo y universitario de la región. Ostenta los títulos de «muy noble, muy leal, benemérita, invicta, heroica y buena» que figuran en el escudo.​</p>
                                <a href=\"#oviedo\" class=\"main-button\" data-toggle=\"modal\">Ver mapa</a>
                            </div>
                        </div>
                    </div>
                    <!-- /single event -->

                </div>
                <!-- /row -->

            </div>
            <!-- /container -->

        </div>
        <!-- /Events -->
";
        // line 702
        echo "
        <!-- Reservation -->
        <div id=\"reservation\" class=\"section\">

            <!-- Backgound Image -->
            <div class=\"bg-image\" style=\"background-image:url(views/app/images/fondo4.jpg)\"></div>
            <!-- /Backgound Image -->

            <!-- container -->
            <div class=\"container\">

                <!-- row -->
                <div class=\"row\">

                    <!-- reservation form -->
                    <div class=\"col-md-6 col-md-offset-1 col-sm-10 col-sm-offset-1\">
                        <div class=\"reserve-form row\">
                            <div class=\"section-header text-center\">
                                <h4 class=\"sub-title\">Reservas</h4>
                                <h2 class=\"title white-text\">Reserve su mesa</h2>
                                <p>Para realizar la reserva llame al teléfono del restaurante que prefiera:</p>
                            </div>

                            <div class=\"col-md-12 text-center\">
                                <p>Ribadesella: <a href=\"tel:+34985860358\"> 985 86 03 58</a></p>
                                <p>Cangas de onís: <a href=\"tel:+34985947446\"> 985 94 74 46</a></p>
                                <p>Oviedo: <a href=\"tel:+34985215193\"> 985 21 51 93</a></p>
                                <ul class=\"list-inline\">
                                    <li><p>Síguenos en:</p></li>
                                    <li><a href=\"htpps://www.facebook.com/elcampanu\"><i class=\"fa fa-facebook\"></i></a></li>
                                    <li><a href=\"htpps://twitter.com/elcampanu\"><i class=\"fa fa-twitter\"></i></a></li>
                                </ul>
                            </div>

                            <div class=\"col-md-12 text-center\">
                                <button class=\"main-button\">Haga su reserva</button>
                            </div>

                        </div>
                    </div>
                    <!-- /reservation form -->

                    <!-- opening time -->
                    <div class=\"col-md-4 col-md-offset-0 col-sm-10 col-sm-offset-1\">
                        <div class=\"opening-time row\">
                            <div class=\"section-header text-center\">
                                <h2 class=\"title white-text\">Horario</h2>
                            </div>
                            <ul>
                                <li>
                                    <h4 class=\"day\">Lunes</h4>
                                    <h4 class=\"hours\">8:00 am – 11:00 pm</h4>
                                </li>
                                <li>
                                    <h4 class=\"day\">Martes</h4>
                                    <h4 class=\"hours\">8:00 am – 11:00 pm</h4>
                                </li>
                                <li>
                                    <h4 class=\"day\">Miércoles</h4>
                                    <h4 class=\"hours\">8:00 am – 11:00 pm</h4>
                                </li>
                                <li>
                                    <h4 class=\"day\">Jueves</h4>
                                    <h4 class=\"hours\">8:00 am – 11:00 pm</h4>
                                </li>
                                <li>
                                    <h4 class=\"day\">Viernes</h4>
                                    <h4 class=\"hours\">8:00 am – 11:00 pm</h4>
                                </li>
                                <li>
                                    <h4 class=\"day\">Sábado</h4>
                                    <h4 class=\"hours\">8:00 am – 11:00 pm</h4>
                                </li>
                                <li>
                                    <h4 class=\"day\">Domingo</h4>
                                    <h4 class=\"hours\">8:00 am – 11:00 pm</h4>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- /opening time -->

                </div>
                <!-- /row -->

            </div>
            <!-- /container -->

        </div>
        <!-- /Reservation -->

        <!-- Footer -->
        <footer id=\"footer\">

            <!-- container -->
            <div class=\"container\">

                <!-- row -->
                <div class=\"row\">

                    <!-- copyright -->
                    <div class=\"col-md-6\">
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        <span class=\"copyright\">Copyright @";
        // line 805
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " Restaurante <br> Esta página está modificada con <i class=\"fa fa-heart-o\" aria-hidden=\"true\"></i> por Jose Luis Acebedo Parajón a través de las plantillas de <a href=\"https://colorlib.com\" target=\"_blank\">Colorlib</a></span>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </div>
                    <!-- /copyright -->

                    <!-- footer nav -->
                    <div class=\"col-md-6\">
                        <nav class=\"footer-nav\">
                            <a href=\"index.php\">Inicio</a>
                            <a href=\"#about\">Historia</a>
                            <a href=\"#menu\">Platos</a>
                            ";
        // line 817
        echo "                            <a href=\"#restaurantes\">Restaurantes</a>
                            <a href=\"#reservation\">Contacto y reserva</a>
                        </nav>
                    </div>
                    <!-- /footer nav -->

                </div>
                <!-- /row -->

            </div>
            <!-- /container -->

        </footer>
        <!-- /Footer -->

        <!-- Ventanas modales visualizar mapas -->
        <!-- Ribadesella -->
        <div id=\"ribadesella\" class=\"modal fade\">
            <div class=\"modal-dialog\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                        <h4 class=\"modal-title\">Restaurante en Ribadesella</h4>
                    </div>
                    <div class=\"modal-body\">
                        <iframe class=\"ytb-embed\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d430.47564393353736!2d-5.058725903250854!3d43.46303127873432!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd49e209e565ec05%3A0x2b6f94959c7b6c72!2sEl+Campanu!5e0!3m2!1ses!2ses!4v1524137962078\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>
                    </div>
                    <div class=\"modal-footer\">
                        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>

        <div id=\"cangas\" class=\"modal fade\">
            <div class=\"modal-dialog\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                        <h4 class=\"modal-title\">Restaurante en Cangas de Onís</h4>
                    </div>
                    <div class=\"modal-body\">
                        <iframe class=\"ytb-embed\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d431.27820945361015!2d-5.131524242847082!3d43.35020312550735!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd3621ed63fbc035%3A0xde53548e0d3c9fcb!2sRestaurante+Sidrer%C3%ADa+El+Campanu!5e0!3m2!1ses!2ses!4v1524138218490\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>
                    </div>
                    <div class=\"modal-footer\">
                        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>

        <div id=\"oviedo\" class=\"modal fade\">
            <div class=\"modal-dialog\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                        <h4 class=\"modal-title\">Restaurante en Oviedo</h4>
                    </div>
                    <div class=\"modal-body\">
                        <iframe class=\"ytb-embed\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d431.2043829214066!2d-5.846218769848205!3d43.360591801596186!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd368cef7d84b6bb%3A0x68b4b93305605cfa!2sSidreria+marisqueria+El+Campanu!5e0!3m2!1ses!2ses!4v1524138298352\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>
                    </div>
                    <div class=\"modal-footer\">
                        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Preloader -->
        <div id=\"preloader\">
            <div class=\"preloader\">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
        <!-- /Preloader -->
";
    }

    public function getTemplateName()
    {
        return "home/home.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  876 => 817,  862 => 805,  757 => 702,  735 => 609,  716 => 586,  697 => 563,  675 => 537,  657 => 407,  650 => 405,  639 => 401,  634 => 399,  630 => 398,  625 => 395,  620 => 394,  617 => 393,  613 => 392,  602 => 383,  595 => 381,  584 => 377,  579 => 375,  575 => 374,  570 => 371,  565 => 370,  562 => 369,  558 => 368,  547 => 359,  540 => 357,  529 => 353,  524 => 351,  520 => 350,  515 => 347,  510 => 346,  507 => 345,  503 => 344,  491 => 334,  484 => 332,  473 => 328,  468 => 326,  464 => 325,  459 => 322,  454 => 321,  451 => 320,  447 => 319,  440 => 314,  433 => 312,  422 => 308,  417 => 306,  413 => 305,  408 => 302,  403 => 301,  400 => 300,  396 => 299,  389 => 294,  382 => 292,  371 => 288,  366 => 286,  362 => 285,  357 => 282,  352 => 281,  349 => 280,  345 => 279,  330 => 266,  322 => 259,  319 => 257,  311 => 254,  300 => 251,  295 => 249,  291 => 248,  286 => 245,  281 => 244,  278 => 243,  274 => 242,  94 => 64,  78 => 49,  31 => 3,  28 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "home/home.twig", "/storage/ssd4/489/5421489/public_html/app/templates/home/home.twig");
    }
}
