<?php

/* overall/layout.twig */
class __TwigTemplate_082cd4cb68d6ff15f82672f98bb6ef1b2d8b2302577095d2a73b4245fb760937 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'appHead' => array($this, 'block_appHead'),
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"es\">
  <head>
    ";
        // line 5
        echo "    <base href=\"https://campanu.000webhostapp.com\"> 
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
    
     ";
        // line 10
        echo " 
    <link href=\"https://fonts.googleapis.com/css?family=Quicksand:400,700%7CCabin:400%7CDancing+Script\" rel=\"stylesheet\">
    ";
        // line 13
        echo "    <link href=\"views/app/vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\" />
    <link href=\"views/app/css/framework.min.css\" rel=\"stylesheet\" />

    ";
        // line 17
        echo "    <link type=\"text/css\" rel=\"stylesheet\" href=\"views/app/css/owl.carousel.css\" />
    <link type=\"text/css\" rel=\"stylesheet\" href=\"views/app/css/owl.theme.default.css\" />

    ";
        // line 20
        echo " 
    <link rel=\"stylesheet\" href=\"views/app/css/font-awesome.min.css\">

    ";
        // line 23
        echo " 
    <link type=\"text/css\" rel=\"stylesheet\" href=\"views/app/css/style.css\"/>
    <link href=\"views/app/images/favicon.ico\" rel=\"shortcut icon\" type=\"image/x-icon\" />

    ";
        // line 28
        echo "    <title>";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "site", array()), "name", array()), "html", null, true);
        echo "</title>

    <meta name=\"Keywords\" content=\"campanu, El Campanu, restaurante, sidreria, marisqueria, parrilla, ribadesella, asturias\" />
    <meta name=\"Description\" content=\"Restaurantes El Campanu. Sidrería marisquería. Desde 1998, ofreciendo platos tradicionales de la máxima calidad.\" />
    <meta name=\"robots\" content=\"index,follow\">
    <meta name=\"revisit-after\" content=\"30 days\">

    <!-- Metas de Facebook. You can use open graph tags to customize link previews.
    Learn more: https://developers.facebook.com/docs/sharing/webmasters -->
  <meta property=\"og:url\" content=\"http://www.elcampanu.com/index.html\" />
  <meta property=\"og:type\" content=\"website\" />
  <meta property=\"og:title\" content=\"Sidrería El Campanu\" />
  <meta property=\"og:description\" content=\"Restaurantes El Campanu. Sidrería marisquería. Desde 1998, ofreciendo platos tradicionales de la máxima calidad..\" />
  <meta property=\"og:image\" content=\"http://www.elcampanu.com/views/app/images/logocampanu.png\" />

    ";
        // line 44
        echo "    ";
        $this->displayBlock('appHead', $context, $blocks);
        // line 47
        echo "    
    <!--[if lt IE 9]>
      <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
      <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->
  </head>
  <body>

    ";
        // line 56
        echo "    ";
        $this->displayBlock('appBody', $context, $blocks);
        // line 59
        echo "
    ";
        // line 61
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "framework", array()), "debug", array())) {
            // line 62
            echo "      ";
            // line 63
            echo "      <script src=\"views/app/js/jdev.min.js\"></script>
    ";
        } else {
            // line 65
            echo "      ";
            // line 66
            echo "      <script src=\"views/app/js/jquery.min.js\"></script>
    ";
        }
        // line 68
        echo "
    ";
        // line 70
        echo "    <script src=\"views/app/js/bootstrap.min.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/owl.carousel.min.js\"></script>
    <script src=\"https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/google-map.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/main.js\"></script>

    ";
        // line 77
        echo "    ";
        $this->displayBlock('appFooter', $context, $blocks);
        // line 80
        echo "  </body>
</html>
";
    }

    // line 44
    public function block_appHead($context, array $blocks = array())
    {
        // line 45
        echo "      <!-- :) -->
    ";
    }

    // line 56
    public function block_appBody($context, array $blocks = array())
    {
        // line 57
        echo "      <!-- :) -->
    ";
    }

    // line 77
    public function block_appFooter($context, array $blocks = array())
    {
        // line 78
        echo "      <!-- :) -->
    ";
    }

    public function getTemplateName()
    {
        return "overall/layout.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  151 => 78,  148 => 77,  143 => 57,  140 => 56,  135 => 45,  132 => 44,  126 => 80,  123 => 77,  115 => 70,  112 => 68,  108 => 66,  106 => 65,  102 => 63,  100 => 62,  97 => 61,  94 => 59,  91 => 56,  81 => 47,  78 => 44,  59 => 28,  53 => 23,  48 => 20,  43 => 17,  38 => 13,  34 => 10,  27 => 5,  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"es\">
  <head>
    {# Formato #}
    <base href=\"https://campanu.000webhostapp.com\"> 
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
    
     {# Google font #} 
    <link href=\"https://fonts.googleapis.com/css?family=Quicksand:400,700%7CCabin:400%7CDancing+Script\" rel=\"stylesheet\">
    {# Estilos #}
    <link href=\"views/app/vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\" />
    <link href=\"views/app/css/framework.min.css\" rel=\"stylesheet\" />

    {# owl carrousel #}
    <link type=\"text/css\" rel=\"stylesheet\" href=\"views/app/css/owl.carousel.css\" />
    <link type=\"text/css\" rel=\"stylesheet\" href=\"views/app/css/owl.theme.default.css\" />

    {# Font Awesome Icon #} 
    <link rel=\"stylesheet\" href=\"views/app/css/font-awesome.min.css\">

    {# Custom stlylesheet #} 
    <link type=\"text/css\" rel=\"stylesheet\" href=\"views/app/css/style.css\"/>
    <link href=\"views/app/images/favicon.ico\" rel=\"shortcut icon\" type=\"image/x-icon\" />

    {# Título #}
    <title>{{ config.site.name }}</title>

    <meta name=\"Keywords\" content=\"campanu, El Campanu, restaurante, sidreria, marisqueria, parrilla, ribadesella, asturias\" />
    <meta name=\"Description\" content=\"Restaurantes El Campanu. Sidrería marisquería. Desde 1998, ofreciendo platos tradicionales de la máxima calidad.\" />
    <meta name=\"robots\" content=\"index,follow\">
    <meta name=\"revisit-after\" content=\"30 days\">

    <!-- Metas de Facebook. You can use open graph tags to customize link previews.
    Learn more: https://developers.facebook.com/docs/sharing/webmasters -->
  <meta property=\"og:url\" content=\"http://www.elcampanu.com/index.html\" />
  <meta property=\"og:type\" content=\"website\" />
  <meta property=\"og:title\" content=\"Sidrería El Campanu\" />
  <meta property=\"og:description\" content=\"Restaurantes El Campanu. Sidrería marisquería. Desde 1998, ofreciendo platos tradicionales de la máxima calidad..\" />
  <meta property=\"og:image\" content=\"http://www.elcampanu.com/views/app/images/logocampanu.png\" />

    {# Extras en el head #}
    {% block appHead %}
      <!-- :) -->
    {% endblock %}
    
    <!--[if lt IE 9]>
      <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
      <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->
  </head>
  <body>

    {# Contenido real #}
    {% block appBody %}
      <!-- :) -->
    {% endblock %}

    {# Carga de jQuery #}
    {% if config.framework.debug %}
      {# jQuery para ver errores de ajax vía consola, no eliminar #}
      <script src=\"views/app/js/jdev.min.js\"></script>
    {% else %}
      {# jQuery para su plantilla, este puede ser modificado a voluntad #}
      <script src=\"views/app/js/jquery.min.js\"></script>
    {% endif %}

    {# Scripts globales #}
    <script src=\"views/app/js/bootstrap.min.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/owl.carousel.min.js\"></script>
    <script src=\"https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/google-map.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/main.js\"></script>

    {# Footer #}
    {% block appFooter %}
      <!-- :) -->
    {% endblock %}
  </body>
</html>
", "overall/layout.twig", "/storage/ssd4/489/5421489/public_html/app/templates/overall/layout.twig");
    }
}
