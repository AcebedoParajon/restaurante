<?php

/* overall/layout.twig */
class __TwigTemplate_14c1f3c39ad2baea8c2d58030dbc1ca140bea73384e725c62558f9a276527ee4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'appHead' => array($this, 'block_appHead'),
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"es\">
  <head>
    ";
        // line 5
        echo "    <base href=\"campanu.000webhostapp.com\">
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
    
     ";
        // line 10
        echo " 
    <link href=\"https://fonts.googleapis.com/css?family=Quicksand:400,700%7CCabin:400%7CDancing+Script\" rel=\"stylesheet\">
    ";
        // line 13
        echo "    ";
        // line 15
        echo "
    ";
        // line 17
        echo "    ";
        // line 19
        echo "
    ";
        // line 20
        echo " 
    ";
        // line 22
        echo "
    ";
        // line 23
        echo " 
    ";
        // line 25
        echo "
    ";
        // line 27
        echo "    <link rel=\"stylesheet\" href=\"views/app/css/csslimpio.css\">
    ";
        // line 29
        echo "    <link href=\"views/app/images/logocampanu.ico\" rel=\"shortcut icon\" type=\"image/x-icon\" />

    ";
        // line 32
        echo "    <title>Restaurante</title>

    ";
        // line 35
        echo "    ";
        $this->displayBlock('appHead', $context, $blocks);
        // line 38
        echo "    
    <!--[if lt IE 9]>
      <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
      <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->
  </head>
  <body>

    ";
        // line 47
        echo "    ";
        $this->displayBlock('appBody', $context, $blocks);
        // line 50
        echo "
    ";
        // line 52
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "framework", array()), "debug", array())) {
            // line 53
            echo "      ";
            // line 54
            echo "      <script src=\"views/app/js/jdev.min.js\"></script>
    ";
        } else {
            // line 56
            echo "      ";
            // line 57
            echo "      <script src=\"views/app/js/jquery.min.js\"></script>
    ";
        }
        // line 59
        echo "
    ";
        // line 61
        echo "    <script src=\"views/app/js/bootstrap.min.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/owl.carousel.min.js\"></script>
   ";
        // line 64
        echo "    <script type=\"text/javascript\" src=\"js/google-map.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/main.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/expand.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/jquery.waypoints.min.js\"></script>
    <script>
    \$(document).ready(function(){
 
      // hide our element on page load
      \$('.animado').css('opacity', 0);
        \$('.animado').waypoint(function() {
              \$('.animado').css('opacity',1).addClass('animated slideInLeft');
          }, { 
            offset: '70%',
            triggerOnce: true 
        });
    });

    </script>  
    ";
        // line 83
        echo "    ";
        $this->displayBlock('appFooter', $context, $blocks);
        // line 86
        echo "  </body>
</html>
";
    }

    // line 35
    public function block_appHead($context, array $blocks = array())
    {
        // line 36
        echo "      <!-- :) -->
    ";
    }

    // line 47
    public function block_appBody($context, array $blocks = array())
    {
        // line 48
        echo "      <!-- :) -->
    ";
    }

    // line 83
    public function block_appFooter($context, array $blocks = array())
    {
        // line 84
        echo "      <!-- :) -->
    ";
    }

    public function getTemplateName()
    {
        return "overall/layout.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  160 => 84,  157 => 83,  152 => 48,  149 => 47,  144 => 36,  141 => 35,  135 => 86,  132 => 83,  112 => 64,  108 => 61,  105 => 59,  101 => 57,  99 => 56,  95 => 54,  93 => 53,  90 => 52,  87 => 50,  84 => 47,  74 => 38,  71 => 35,  67 => 32,  63 => 29,  60 => 27,  57 => 25,  54 => 23,  51 => 22,  48 => 20,  45 => 19,  43 => 17,  40 => 15,  38 => 13,  34 => 10,  27 => 5,  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "overall/layout.twig", "/storage/ssd4/489/5421489/public_html/app/templates/overall/layout.twig");
    }
}
