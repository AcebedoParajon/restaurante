<?php

/* administrar/administrar.twig */
class __TwigTemplate_2dce2a0eb98d252f5464da1388a9b576685bb70cb71b5b0fab2165318768850b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "administrar/administrar.twig", 1);
        $this->blocks = array(
            'appBody' => array($this, 'block_appBody'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appBody($context, array $blocks = array())
    {
        // line 3
        echo "    
<div class=\"container\">
    <nav class=\"nav navbar navbar-fixed-top text-center\">
        <a href=\"administrar/crear\" class=\"btn btn-success\">+ Crear nuevo</a>
        <a href=\"administrar/newpass\" class=\"btn btn-info\">Cambiar contraseña</a>
        <a href=\"logout/\" class=\"btn btn-primary\">Cerrar sesión</a>
    </nav>
        <div class=\"col-xs-12 col-md-12 col-lg-12 section\">
            <table class=\"table table-bordered\">
                <thead>
                    <tr>
                        <th>Categoria</th>
                    
                        <th>Plato</th>
                    
                        <th>Precio</th>
                    
                        <th>Descripción</th>
                    
                        <th>Acciones</th> 
                    </tr>
                </thead>
                <tbody>
                    ";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["d"]) {
            if ((false != ($context["data"] ?? null))) {
                // line 27
                echo "                    <tr>
                        <td>";
                // line 28
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "categoria", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 29
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "plato", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 30
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "precio", array()), "html", null, true);
                echo "€</td>
                        <td>";
                // line 31
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "descripcion", array()), "html", null, true);
                echo "</td>
                        <td>
                            <a href=\"administrar/editar/";
                // line 33
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "id_platos", array()), "html", null, true);
                echo "\">Editar</a>
                            <a href=\"administrar/eliminar/";
                // line 34
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["d"], "id_platos", array()), "html", null, true);
                echo "\">Eliminar</a>
                        </td> 
                    </tr>
                    ";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['d'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo "                </tbody>
            </table>
        </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "administrar/administrar.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 38,  85 => 34,  81 => 33,  76 => 31,  72 => 30,  68 => 29,  64 => 28,  61 => 27,  56 => 26,  31 => 3,  28 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "administrar/administrar.twig", "/storage/ssd4/489/5421489/public_html/app/templates/administrar/administrar.twig");
    }
}
