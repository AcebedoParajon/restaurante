<?php

/* overall/layout.twig */
class __TwigTemplate_b1e8058f75be4483ae10bff593ef64b0a054db44b87180d1638412da8c0172c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'appHead' => array($this, 'block_appHead'),
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"es\">
  <head>
    ";
        // line 5
        echo "    ";
        echo $this->env->getExtension('Ocrend\Kernel\Helpers\Functions')->base_assets();
        echo "
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
    
     ";
        // line 10
        echo " 
    <link href=\"https://fonts.googleapis.com/css?family=Quicksand:400,700%7CCabin:400%7CDancing+Script\" rel=\"stylesheet\">
    ";
        // line 13
        echo "    <link href=\"views/app/vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\" />
    <link href=\"views/app/css/framework.min.css\" rel=\"stylesheet\" />

    ";
        // line 17
        echo "    <link type=\"text/css\" rel=\"stylesheet\" href=\"views/app/css/owl.carousel.css\" />
    <link type=\"text/css\" rel=\"stylesheet\" href=\"views/app/css/owl.theme.default.css\" />

    ";
        // line 20
        echo " 
    <link rel=\"stylesheet\" href=\"views/app/css/font-awesome.min.css\">

    ";
        // line 23
        echo " 
    <link type=\"text/css\" rel=\"stylesheet\" href=\"views/app/css/style.css\"/>
    <link href=\"views/app/images/logocampanu.ico\" rel=\"shortcut icon\" type=\"image/x-icon\" />

    ";
        // line 28
        echo "    <title>";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "site", array()), "name", array()), "html", null, true);
        echo "</title>

    ";
        // line 31
        echo "    ";
        $this->displayBlock('appHead', $context, $blocks);
        // line 34
        echo "    
    <!--[if lt IE 9]>
      <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
      <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->
  </head>
  <body>

    ";
        // line 43
        echo "    ";
        $this->displayBlock('appBody', $context, $blocks);
        // line 46
        echo "
    ";
        // line 48
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "framework", array()), "debug", array())) {
            // line 49
            echo "      ";
            // line 50
            echo "      <script src=\"views/app/js/jdev.min.js\"></script>
    ";
        } else {
            // line 52
            echo "      ";
            // line 53
            echo "      <script src=\"views/app/js/jquery.min.js\"></script>
    ";
        }
        // line 55
        echo "
    ";
        // line 57
        echo "    <script src=\"views/app/js/bootstrap.min.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/owl.carousel.min.js\"></script>
    <script src=\"https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false\"></script>
    <script type=\"text/javascript\" src=\"js/google-map.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/main.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/cuentadivs.js\"></script>
    ";
        // line 64
        echo "    ";
        $this->displayBlock('appFooter', $context, $blocks);
        // line 67
        echo "  </body>
</html>
";
    }

    // line 31
    public function block_appHead($context, array $blocks = array())
    {
        // line 32
        echo "      <!-- :) -->
    ";
    }

    // line 43
    public function block_appBody($context, array $blocks = array())
    {
        // line 44
        echo "      <!-- :) -->
    ";
    }

    // line 64
    public function block_appFooter($context, array $blocks = array())
    {
        // line 65
        echo "      <!-- :) -->
    ";
    }

    public function getTemplateName()
    {
        return "overall/layout.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  140 => 65,  137 => 64,  132 => 44,  129 => 43,  124 => 32,  121 => 31,  115 => 67,  112 => 64,  104 => 57,  101 => 55,  97 => 53,  95 => 52,  91 => 50,  89 => 49,  86 => 48,  83 => 46,  80 => 43,  70 => 34,  67 => 31,  61 => 28,  55 => 23,  50 => 20,  45 => 17,  40 => 13,  36 => 10,  27 => 5,  22 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"es\">
  <head>
    {# Formato #}
    {{ base_assets()|raw }}
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
    
     {# Google font #} 
    <link href=\"https://fonts.googleapis.com/css?family=Quicksand:400,700%7CCabin:400%7CDancing+Script\" rel=\"stylesheet\">
    {# Estilos #}
    <link href=\"views/app/vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\" />
    <link href=\"views/app/css/framework.min.css\" rel=\"stylesheet\" />

    {# owl carrousel #}
    <link type=\"text/css\" rel=\"stylesheet\" href=\"views/app/css/owl.carousel.css\" />
    <link type=\"text/css\" rel=\"stylesheet\" href=\"views/app/css/owl.theme.default.css\" />

    {# Font Awesome Icon #} 
    <link rel=\"stylesheet\" href=\"views/app/css/font-awesome.min.css\">

    {# Custom stlylesheet #} 
    <link type=\"text/css\" rel=\"stylesheet\" href=\"views/app/css/style.css\"/>
    <link href=\"views/app/images/logocampanu.ico\" rel=\"shortcut icon\" type=\"image/x-icon\" />

    {# Título #}
    <title>{{ config.site.name }}</title>

    {# Extras en el head #}
    {% block appHead %}
      <!-- :) -->
    {% endblock %}
    
    <!--[if lt IE 9]>
      <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
      <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->
  </head>
  <body>

    {# Contenido real #}
    {% block appBody %}
      <!-- :) -->
    {% endblock %}

    {# Carga de jQuery #}
    {% if config.framework.debug %}
      {# jQuery para ver errores de ajax vía consola, no eliminar #}
      <script src=\"views/app/js/jdev.min.js\"></script>
    {% else %}
      {# jQuery para su plantilla, este puede ser modificado a voluntad #}
      <script src=\"views/app/js/jquery.min.js\"></script>
    {% endif %}

    {# Scripts globales #}
    <script src=\"views/app/js/bootstrap.min.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/owl.carousel.min.js\"></script>
    <script src=\"https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false\"></script>
    <script type=\"text/javascript\" src=\"js/google-map.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/main.js\"></script>
    <script type=\"text/javascript\" src=\"views/app/js/cuentadivs.js\"></script>
    {# Footer #}
    {% block appFooter %}
      <!-- :) -->
    {% endblock %}
  </body>
</html>
", "overall/layout.twig", "C:\\xampp\\htdocs\\campanu\\app\\templates\\overall\\layout.twig");
    }
}
