<?php

/* administrar/crear.twig */
class __TwigTemplate_8336b8d894f7df46160cbbb391cc6f54d26d73fa514b59cf3e0d4c65b57a1dd1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "administrar/crear.twig", 1);
        $this->blocks = array(
            'appHead' => array($this, 'block_appHead'),
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appHead($context, array $blocks = array())
    {
        // line 3
        echo "\t<link rel=\"stylesheet\" href=\"views/app/plugins/css/jquery-confirm.min.css\">
";
    }

    // line 5
    public function block_appBody($context, array $blocks = array())
    {
        // line 6
        echo "    <div class=\"container\">
        <form role=\"form\" id=\"administrar_form\">
\t\t\t<div class=\"form-group\">
\t\t\t\t<input type=\"hidden\" name=\"id_platos\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "id_platos", array()), "html", null, true);
        echo "\" />
\t\t\t\t<label for=\"\">Categoria</label>
\t\t\t\t<select name=\"categoria\">
\t\t\t\t\t<option value=\"entrantes\">entrante</option>
\t\t\t\t\t<option value=\"carnes\">carnes</option>
\t\t\t\t\t<option value=\"mariscos\">mariscos</option>
\t\t\t\t\t<option value=\"pescados\">pescados</option>
\t\t\t\t\t<option value=\"parrillada mariscos pescados\">parrillada mariscos pescados</option>
\t\t\t\t\t<option value=\"cuchara\">cuchara</option>
\t\t\t\t</select><br>
\t\t\t\t<label for=\"\">Plato</label>
\t\t\t\t<input type=\"text\" class=\"form-control\" placeholder=\"nombre del plato\"  name=\"plato\" required>
\t\t\t\t<label for=\"\">precio</label>
\t\t\t\t<input type=\"text\" class=\"form-control\" placeholder=\"precio (opcional)\" =\"precio\" name=\"precio\">
\t\t\t\t<label for=\"\">descripcion</label>
\t\t\t\t<input type=\"text\" class=\"form-control\" placeholder=\"descripcion (opcional)\"  name=\"descripcion\">
\t\t\t</div>


            <div class=\"form-group\">
                <button type=\"button\" class=\"btn btn-success\" id=\"administrar\">Crear nuevo</button>
                <a href=\"administrar/\" class=\"btn btn-primary\">Atrás</a>
            </div>
        </form>
    </div>
";
    }

    // line 35
    public function block_appFooter($context, array $blocks = array())
    {
        // line 36
        echo "\t<script src=\"views/app/plugins/js/jquery-confirm.min.js\"></script>
    <script src=\"views/app/js/administrar/crear.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "administrar/crear.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 36,  76 => 35,  46 => 9,  41 => 6,  38 => 5,  33 => 3,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout' %}
{% block appHead %}
\t<link rel=\"stylesheet\" href=\"views/app/plugins/css/jquery-confirm.min.css\">
{% endblock %}
{% block appBody %}
    <div class=\"container\">
        <form role=\"form\" id=\"administrar_form\">
\t\t\t<div class=\"form-group\">
\t\t\t\t<input type=\"hidden\" name=\"id_platos\" value=\"{{ data.id_platos }}\" />
\t\t\t\t<label for=\"\">Categoria</label>
\t\t\t\t<select name=\"categoria\">
\t\t\t\t\t<option value=\"entrantes\">entrante</option>
\t\t\t\t\t<option value=\"carnes\">carnes</option>
\t\t\t\t\t<option value=\"mariscos\">mariscos</option>
\t\t\t\t\t<option value=\"pescados\">pescados</option>
\t\t\t\t\t<option value=\"parrillada mariscos pescados\">parrillada mariscos pescados</option>
\t\t\t\t\t<option value=\"cuchara\">cuchara</option>
\t\t\t\t</select><br>
\t\t\t\t<label for=\"\">Plato</label>
\t\t\t\t<input type=\"text\" class=\"form-control\" placeholder=\"nombre del plato\"  name=\"plato\" required>
\t\t\t\t<label for=\"\">precio</label>
\t\t\t\t<input type=\"text\" class=\"form-control\" placeholder=\"precio (opcional)\" =\"precio\" name=\"precio\">
\t\t\t\t<label for=\"\">descripcion</label>
\t\t\t\t<input type=\"text\" class=\"form-control\" placeholder=\"descripcion (opcional)\"  name=\"descripcion\">
\t\t\t</div>


            <div class=\"form-group\">
                <button type=\"button\" class=\"btn btn-success\" id=\"administrar\">Crear nuevo</button>
                <a href=\"administrar/\" class=\"btn btn-primary\">Atrás</a>
            </div>
        </form>
    </div>
{% endblock %}
{% block appFooter %}
\t<script src=\"views/app/plugins/js/jquery-confirm.min.js\"></script>
    <script src=\"views/app/js/administrar/crear.js\"></script>
{% endblock %}", "administrar/crear.twig", "C:\\xampp\\htdocs\\campanu\\app\\templates\\administrar\\crear.twig");
    }
}
