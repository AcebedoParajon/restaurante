<?php

/* administrar/newpass.twig */
class __TwigTemplate_03860ccf2deeb31792bef5f4791747d068e7520e09b67a43031445e5d9924c78 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("overall/layout", "administrar/newpass.twig", 1);
        $this->blocks = array(
            'appHead' => array($this, 'block_appHead'),
            'appBody' => array($this, 'block_appBody'),
            'appFooter' => array($this, 'block_appFooter'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "overall/layout";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_appHead($context, array $blocks = array())
    {
        // line 3
        echo "\t<link rel=\"stylesheet\" href=\"views/app/plugins/css/jquery-confirm.min.css\">
";
    }

    // line 5
    public function block_appBody($context, array $blocks = array())
    {
        // line 6
        echo "    <div class=\"container\">
        <form role=\"form\" enctype=\"application/x-www-form-urlencoded\" id=\"newpass_form\">
\t\t\t<div class=\"form-group\">
\t\t\t\t<input type=\"hidden\" name=\"id_user\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["data"] ?? null), "id_user", array()), "html", null, true);
        echo "\" />
\t\t\t\t<label for=\"\">Contraseña actual: </label>
\t\t\t\t<input type=\"password\" class=\"form-control\" placeholder=\"contraseña actual\" name=\"pass\" required=\"\">
\t\t\t\t<label for=\"\">Nueva contraseña:</label>
\t\t\t\t<input type=\"password\" class=\"form-control\" placeholder=\"nueva contraseña\" name=\"newpass\" required=\"\">
\t\t\t\t<label for=\"\">Repita nueva contraseña:</label>
\t\t\t\t<input type=\"password\" class=\"form-control\" placeholder=\"repita contraseña\" name=\"newpass2\" required=\"\">
\t\t\t\t
\t\t\t</div>


            <div class=\"form-group\">
                <button type=\"button\" class=\"btn btn-success\" id=\"newpass\">Cambiar contraseña</button>
                <a href=\"administrar/\" class=\"btn btn-primary\">Atrás</a>
            </div>
        </form>
    </div>
";
    }

    // line 27
    public function block_appFooter($context, array $blocks = array())
    {
        // line 28
        echo "\t<script src=\"views/app/plugins/js/jquery-confirm.min.js\"></script>
    <script src=\"views/app/js/newpass/newpass.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "administrar/newpass.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 28,  68 => 27,  46 => 9,  41 => 6,  38 => 5,  33 => 3,  30 => 2,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'overall/layout' %}
{% block appHead %}
\t<link rel=\"stylesheet\" href=\"views/app/plugins/css/jquery-confirm.min.css\">
{% endblock %}
{% block appBody %}
    <div class=\"container\">
        <form role=\"form\" enctype=\"application/x-www-form-urlencoded\" id=\"newpass_form\">
\t\t\t<div class=\"form-group\">
\t\t\t\t<input type=\"hidden\" name=\"id_user\" value=\"{{ data.id_user }}\" />
\t\t\t\t<label for=\"\">Contraseña actual: </label>
\t\t\t\t<input type=\"password\" class=\"form-control\" placeholder=\"contraseña actual\" name=\"pass\" required=\"\">
\t\t\t\t<label for=\"\">Nueva contraseña:</label>
\t\t\t\t<input type=\"password\" class=\"form-control\" placeholder=\"nueva contraseña\" name=\"newpass\" required=\"\">
\t\t\t\t<label for=\"\">Repita nueva contraseña:</label>
\t\t\t\t<input type=\"password\" class=\"form-control\" placeholder=\"repita contraseña\" name=\"newpass2\" required=\"\">
\t\t\t\t
\t\t\t</div>


            <div class=\"form-group\">
                <button type=\"button\" class=\"btn btn-success\" id=\"newpass\">Cambiar contraseña</button>
                <a href=\"administrar/\" class=\"btn btn-primary\">Atrás</a>
            </div>
        </form>
    </div>
{% endblock %}
{% block appFooter %}
\t<script src=\"views/app/plugins/js/jquery-confirm.min.js\"></script>
    <script src=\"views/app/js/newpass/newpass.js\"></script>
{% endblock %}", "administrar/newpass.twig", "C:\\xampp\\htdocs\\campanu\\app\\templates\\administrar\\newpass.twig");
    }
}
